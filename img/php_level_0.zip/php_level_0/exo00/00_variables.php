<?php

// 1. Réécrivez le nom des variables en « camel case »

$cycle_etude;
$label_qualite;
$taille_entreprise;

// 2. Réécrivez le nom des variables en « snake case »

$compteEntreprise;
$candidatureSpontanee;
$profilCible;
