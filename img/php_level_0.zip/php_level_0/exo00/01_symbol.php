<?php

/*
1. Quel est l'opérateur d'affectation ?
2. Quel est l'opérateur de comparaison d'égalité ?
3. Quel est l'opérateur de concaténation ?
*/
