<?php

// Copiez-collez le tableau que vous avez écrit dans l'exercice 2.01) des tableaux simples (`exo-2/01_associatifs.php`)
// Écrivez le code d'une boucle `foreach` qui affiche dans la console toutes les valeurs du tableau
// Dans le format suivant : `clé = valeur (saut de ligne)`

