<?php

// Copiez-collez le tableau que vous avez écrit dans l'exercice 2) des tableaux simples (`exo02/00_tableaux.php`)
// Écrivez le code d'une boucle `for` qui affiche dans la console toutes les valeurs du tableau
// Vous devez utiliser la fonction `count()` pour déterminer le nombre maximal de boucles

