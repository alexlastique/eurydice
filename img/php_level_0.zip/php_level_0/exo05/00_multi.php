<?php

// 1. Créez une variable `$inventaire` , cette dernière contiendra l'inventaire d'un personnage.
// Affectez-y un tableau multi-dimensionel.
// Chaque case du tableau contient un tableau qui contiendra le nom de l'objet et une quantité

// 2. Affichez le contenu de l'inventaire. (en parcourant le tableau avec une boucle)

$inventaire = [

];


