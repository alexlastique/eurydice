<?php

// 1. Affectez un tableau de trois valeurs de type nombre entier à une variable

// 2. Affectez un tableau de trois valeurs de type chaîne de caractères à une variable
// (Essayez de trouver une autre méthode qu'au point 1.)

// 3. Ajoutez une valeur à la fin du tableau du point 1.

// 4. Ajoutez une valeur à la fin du tableau du point 2. (Avec une autre méthode qu'au point 3.)

