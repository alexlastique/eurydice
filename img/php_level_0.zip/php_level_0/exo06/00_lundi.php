<?php

// 1. Affichez la date de Lundi de la semaine passée, au format `31/01/2022`

// 2. Affichez la date du prochain vendredi, au format : 2022-02-11
// (correspondant à 11/02/2022)

/* Voir fonctions strtotime et date */

echo 'Lundi de la semaine passée: ' . $lundi .PHP_EOL;

echo 'Vendredi qui arrive : '. $vendredi.PHP_EOL;
