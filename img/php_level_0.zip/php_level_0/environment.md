# Mise en place de l'env PHP

- Installer PHP avec brew

```
brew install php
```
