<?php

// 1. Écrivez une ligne de code qui affiche un saut de ligne

// 2. Écrivez d'une autre façon une ligne de code qui affiche un saut de ligne

// 3. Écrivez une ligne de code qui permet d'inscpecter le contenu de la variable $tableau

$tableau = array(
	'pommes' => 56,
	'bacon' => 12,
	'water' => 100
);
